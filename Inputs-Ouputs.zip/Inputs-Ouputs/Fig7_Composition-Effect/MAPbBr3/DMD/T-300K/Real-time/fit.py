#!/usr/bin/env python
from __future__ import print_function
import numpy as np
import scipy.optimize
import sys
from numpy import linalg as LA
import os

fin = ["sx_elec_tot.out", "sy_elec_tot.out", "sz_elec_tot.out"]
if not os.path.isfile("sx_elec_tot.out"):
  fin = ["sx_hole_tot.out", "sy_hole_tot.out","sz_hole_tot.out"]
  if not os.path.isfile("sx_hole_tot.out"):
    print("there is no sx_elec_tot.out and sx_hole_tot.out")
    exit(1)
sdir = np.array([0,0,1])
Bfield = 0 # in-plane (for Sz) magnetic field in Tesla
tstart = 0 # ps
tend = np.inf # ps. if < 0, means +inf
c = 0 # the relative (from 0 to 1) constant part of spin observable.
      # If 0, the constant will be fixed as 0; If not 0, c will be fitted

fit_t2 = len(sys.argv) >= 2 and (sys.argv[1] == "t2star" or sys.argv[1] == "t2-mani" or sys.argv[1] == "t2-wu" or sys.argv[1] == "entropy")
if fit_t2:
  if sys.argv[1] == "entropy":
    fin = [sys.argv[1] + "_elec_tot.out"]
    if len(sys.argv) >= 3 and sys.argv[2] == 'h':
      fin = [sys.argv[1] + "_hole_tot.out"]
  else:
    fin = ["s-" + sys.argv[1] + "_elec_tot.out"]
    if len(sys.argv) >= 3 and sys.argv[2] == 'h':
      fin = ["s-" + sys.argv[1] + "_hole_tot.out"]
elif len(sys.argv) >= 4:
  if LA.norm(sdir) <= 1e-6:
    print("sdir values are too tiny")
    exit(1)
  else:
    sdir = np.array([float(sys.argv[1]), float(sys.argv[2]), float(sys.argv[3])])
    sdir = sdir / LA.norm(sdir)
  if len(sys.argv) >= 5 and sys.argv[4] == 'h':
    fin = ["sx_hole_tot.out", "sy_hole_tot.out","sz_hole_tot.out"]
  if len(sys.argv) == 6:
    Bfield = float(sys.argv[5])
else:
  print("****************************************")
  print("Usage: ./fit.py [sx sy sz] [e/h] [|B| in Tesla]")
  print("       or ./fit.py [t2star/t2-mani/t2-wu/entropy] [e/h]")
  print("Default: ./fit.py 0 0 1 e 0")
  print("(sx,sy,sz) is the direction of spin observable")
  print("e/h means electron or hole")
  print("|B| is initial guess of transverse magnetic field causing oscillation.\n  If 0, fixed to 0; If not 0, will be fitted")
  print("t2star/t2-mani/t2-wu/entropy are other quantities related to T2 or T2*")
  print("****************************************")

print("read file(s): ", fin)
if not fit_t2:
  print("spin observable direction: ",sdir)
  print("initial guess of Bfield: ", Bfield)
print("initial guess of constant part: ", c)

t_data = np.loadtxt(fin[0],usecols=(0,))
nt = t_data.shape[0]
t_data = t_data * 2.4188843265857e-5 # / 40000. # a.u. to ps
mask = (t_data >= tstart) & (t_data <= tend)
t_data = t_data[mask]
print("Fitting range: [",t_data[0],", ",t_data[-1],"] ps")
t_data = t_data - t_data[0]
if fit_t2:
  s_data = np.loadtxt(fin[0],usecols=(1,))[0:nt][mask]
else:
  s_data = sdir[0] * np.loadtxt(fin[0],usecols=(1,))[0:nt][mask] +\
           sdir[1] * np.loadtxt(fin[1],usecols=(1,))[0:nt][mask] +\
           sdir[2] * np.loadtxt(fin[2],usecols=(1,))[0:nt][mask]

sx0 = np.loadtxt(fin[0],usecols=(1,))[0:nt][mask][0]
sy0 = np.loadtxt(fin[1],usecols=(1,))[0:nt][mask][0]
sz0 = np.loadtxt(fin[2],usecols=(1,))[0:nt][mask][0]
print("initial spin: ",sx0,sy0,sz0)

# ==== theoretical parameter values ====
beta = 1 / 1000. # initial guess of rate in 1/ps
Bfield = Bfield / 2.3505175675871e5 # convert to a.u.
omega = Bfield / 2.4188843265857e-5
phi = 0 # phase
if c == 0:
  params = beta, omega, phi
else:
  params = beta, omega, phi, c

# ==== model ====
def decay(t, beta):
  s = s_data[0] * np.exp(-beta*t_data)
  return s
def decay_c(t, beta, c):
  s = s_data[0] * ((1.-c)*np.exp(-beta*t_data) + c)
  return s
def decay_cosine(t, beta, omega, phi):
  s = s_data[0] * np.exp(-beta*t_data) * np.cos(omega*t_data + phi)
  return s
def decay_cosine_c(t, beta, omega, phi, c):
  s = s_data[0] * ((1.-c)*np.exp(-beta*t_data) * np.cos(omega*t_data + phi) + c)
  return s
def residuals1(args, t, s):
  return s - decay(t, *args)
def residuals2(args, t, s):
  return s - decay_cosine(t, *args)
def residuals1c(args, t, s):
  return s - decay_c(t, *args)
def residuals2c(args, t, s):
  return s - decay_cosine_c(t, *args)

# ==== fitting using curve_fit ====
if omega == 0:
  if c == 0:
    params_cf, _ = scipy.optimize.curve_fit(decay, t_data, s_data, maxfev=9999)
    params_lsq, _ = scipy.optimize.leastsq(residuals1, beta, args=(t_data, s_data), maxfev=9999)
  else:
    params_cf, _ = scipy.optimize.curve_fit(decay_c, t_data, s_data, maxfev=9999)
    params_lsq, _ = scipy.optimize.leastsq(residuals1c, beta, args=(t_data, s_data), maxfev=9999)
else:
  if c == 0:
    params_cf, _ = scipy.optimize.curve_fit(decay_cosine, t_data, s_data, maxfev=9999)
    params_lsq, _ = scipy.optimize.leastsq(residuals2, params, args=(t_data, s_data), maxfev=9999)
  else:
    params_cf, _ = scipy.optimize.curve_fit(decay_cosine_c, t_data, s_data, maxfev=9999)
    params_lsq, _ = scipy.optimize.leastsq(residuals2c, params, args=(t_data, s_data), maxfev=9999)

print("Global exponential fit by two ways:")
if omega == 0:
  if c == 0:
    print("cf: tau = ",1/params_cf[0]," ps")
    print("lsq: tau = ",1/params_lsq[0]," ps")
  else:
    print("cf: tau = ",1/params_cf[0]," ps const = ",params_cf[1])
    print("lsq: tau = ",1/params_lsq[0]," ps const = ",params_lsq[1])
else:
  if c == 0:
    print("cf: tau = ",1/params_cf[0]," ps"," period = ",2*np.pi/params_cf[1],"ps"," phi = ",params_cf[2])
    print("lsq: tau = ",1/params_lsq[0]," ps"," period = ",2*np.pi/params_lsq[1],"ps"," phi = ",params_lsq[2])
  else:
    print("cf: tau = ",1/params_cf[0]," ps"," period = ",2*np.pi/params_cf[1],"ps"," phi = ",params_cf[2]," const = ",params_cf[3])
    print("lsq: tau = ",1/params_lsq[0]," ps"," period = ",2*np.pi/params_lsq[1],"ps"," phi = ",params_lsq[2]," const = ",params_lsq[3])

if omega == 0:
  if c == 0:
    s_fit = decay(t_data, params_cf[0])
  else:
    s_fit = decay_c(t_data, params_lsq[0], params_lsq[1])
else:
  if c == 0:
    s_fit = decay_cosine(t_data, params_cf[0], params_cf[1], params_cf[2])
  else:
    s_fit = decay_cosine_c(t_data, params_lsq[0], params_lsq[1], params_lsq[2], params_lsq[3])
np.savetxt("sfit.out", np.transpose([t_data, s_data, s_fit]))

#log fit
s_data = np.log(np.abs(s_data))
nt = t_data.shape[0]
t1 = np.zeros(nt-1)
for it in range(2,nt+1):
  fit = np.polyfit(t_data[it-2:it],s_data[it-2:it],1)
  t1[it-2] = -1. / fit[0] # ps

print("Log fit of time-resolved spin lifetime:")
if nt-1 > 20:
  print(t1[0:10])
  print(t1[nt-11:nt-1])
else:
  print(t1)
np.savetxt("tau_t.dat",np.transpose([t_data[0:nt-1],t1]))
