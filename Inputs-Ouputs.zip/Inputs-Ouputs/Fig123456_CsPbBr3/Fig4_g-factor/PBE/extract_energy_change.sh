#!/bin/bash
grep -A 1 "B field Along \[1 1 0\]" energy_change_Bext.out > ftmp
grep -v "B field Along \[1 1 0\]" ftmp > ftmp2
grep -v "\-\-" ftmp2 > energy_change_B110.dat
grep -A 1 "B field Along \[1 1 0\]" angular_momenta_diag.out > ftmp
grep -v "B field Along \[1 1 0\]" ftmp > ftmp2
grep -v "\-\-" ftmp2 > angular_momenta_diag_B110.dat
rm ftmp*
