#!/bin/bash
#SBATCH -p gpuq
#SBATCH --account=gpuq
#SBATCH -N 2
#SBATCH -t 24:00:00
#SBATCH --ntasks-per-node=5
#SBATCH -J jdftx

module load myopenmpi-4.0.7_gcc gsl

MPICMD="mpirun -np $SLURM_NTASKS"
DIRJ="/data/groups/ping/jxu153/codes/jdftx/jdftx-202201/build"
DIRF="/data/groups/ping/jxu153/codes/jdftx/jdftx-202201/build-FeynWann"

export phononParams="collectPerturbations"
${MPICMD} ${DIRJ}/phonon -i phonon.in > phonon.out
