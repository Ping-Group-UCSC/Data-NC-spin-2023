#!/usr/bin/env python
from __future__ import print_function
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.colors as mcol
from matplotlib.colors import Normalize
import sys

if (len(sys.argv)>1 and (sys.argv[1]=='-h' or sys.argv[1]=='--help')) or (len(sys.argv)<6) or (len(sys.argv)>=8 and len(sys.argv)<10) or (len(sys.argv)>=10 and len(sys.argv)<13):
  print ('''Usage: spinTexture.py <b> <k0> <k1> <k2> <dk> [<nK>=16] [<Ra>=0 <Rb>=0 <Rg>=0] [<Ez>=0] [modelSOC alpha], where:
    <b> : band index (start from 1)
    <k0> <k1> <k2>: target k-point in (dimensionless) reciprocal lattice coordinates
    <dk>: size of square in Cartesian k-space (bohr^-1 units) to explore around target point
    <nK>: number of k-points per dimension in square
    <Ra> <Rb> <Rg>: ZYZ Euler angles [degrees] of target square orientation (default: Cartesian xy-plane)
    <Ez>: Applied electric field in V/nm (requires mlwfZ, default: 0
    <modelSOC alpha kcut>: type of model SOC fields; SOC coefficient alpha; cutoff k.)''')
  exit()

b = int(sys.argv[1]) - 1
k0 = np.array([ float(sys.argv[i]) for i in range(2,5)] )
dk = float(sys.argv[5])
nkPerDim = 16
euler = np.zeros((3,))
Ez = 0.
modelSOC = "none"
if len(sys.argv)>6:
  nkPerDim = int(sys.argv[6])
if len(sys.argv)>7:
  euler = np.array([ float(sys.argv[i]) for i in range(7,10)] )
if len(sys.argv)>10:
  Ez = float(sys.argv[10]) * 0.00194468935814 # from V/nm to a.u.
if len(sys.argv)>12:
  modelSOC = sys.argv[11]
  alpha = float(sys.argv[12])/27.211386/0.529177
  kcut = float(sys.argv[13])

#Get kfold and spin type from output file:
initDone = False
for line in open('totalE.out'):
  if line.startswith('Initialization completed'):
    initDone = True
  if (not initDone) and line.startswith('spintype'):
    spinKey = line.split()[1]
    mlwfType = (np.complex128 if (spinKey=="vector-spin" or spinKey=="spin-orbit") else np.float64)
  if (not initDone) and line.startswith('kpoint-folding'):
    kfold = np.array([int(tok) for tok in line.split()[1:4]])
kfoldProd = np.prod(kfold)
kStride = np.array([kfold[1]*kfold[2], kfold[2], 1])

#Read the wannier cell map and weights:
cellMap = np.loadtxt("wannier.mlwfCellMap", usecols=[0,1,2]).astype(int)
Wwannier = np.fromfile("wannier.mlwfCellWeights", dtype=np.float64)
nCells = cellMap.shape[0]
nBands = int(np.sqrt(Wwannier.shape[0] / nCells))
Wwannier = Wwannier.reshape((nCells,nBands,nBands)).swapaxes(1,2)

#Read and expand Wannier Hamiltonian, spin and gradient matrix elements:
iReduced = np.dot(np.mod(cellMap, kfold[None,:]), kStride)
Hwannier = Wwannier * np.fromfile("wannier.mlwfH", dtype=mlwfType).reshape((kfoldProd,nBands,nBands)).swapaxes(1,2)[iReduced]
Swannier = Wwannier[:,None] * np.fromfile("wannier.mlwfS", dtype=mlwfType).reshape((kfoldProd,3,nBands,nBands)).swapaxes(2,3)[iReduced]
if Ez != 0:
  print("Adding electric field contribution to H")
  Zwannier = Wwannier * np.fromfile("wannier.mlwfZ", dtype=mlwfType).reshape((kfoldProd,nBands,nBands)).swapaxes(1,2)[iReduced]
  Hwannier += Ez * Zwannier

#Get lattice vectors from output file:
R = np.zeros((3,3))
iLine = 0
refLine = -10
initDone = False
Rdone = False
for line in open('totalE.out'):
  if line.find('Initializing the Grid') >= 0:
    refLine = iLine
  if not Rdone:
    rowNum = iLine - (refLine+2)
    if rowNum>=0 and rowNum<3:
      R[rowNum,:] = [ float(x) for x in line.split()[1:-1] ]
    if rowNum==3:
      Rdone = True
  iLine += 1

#Construct k-plane:
kGrid = np.linspace(-0.5*dk, +0.5*dk, nkPerDim+1)
kCart = np.array([x for x in np.meshgrid(kGrid,kGrid, indexing='ij')])
#--- rotate plane
def rotZ(theta):
  c = np.cos(theta/180*np.pi)
  s = np.sin(theta/180*np.pi)
  return np.array([[c,s,0],[-s,c,0],[0,0,1]])
def rotY(theta):
  c = np.cos(theta/180*np.pi)
  s = np.sin(theta/180*np.pi)
  return np.array([[c,0,-s],[0,1,0],[s,0,c]])
rotNet = np.dot(rotZ(euler[0]), np.dot(rotY(euler[1]), rotZ(euler[2])))
kCartRot = np.dot(np.reshape(kCart,(2,-1)).T, rotNet[:2])
kNormal = np.dot(np.array([0,0,1.]), rotNet)
print ('k-plane normal:', kNormal)
#--- kpoints in recip coords with offset:
G = (2*np.pi) * np.linalg.inv(R)
kpoints = (k0[None,:] + np.dot(kCartRot, np.linalg.inv(G))).reshape(kCart.shape[1:] + (3,))

#Calculate Wannier energies and spins:
def fcut(kc):
  kl = np.sqrt(np.sum(kc[0:3]**2))
  return 1/(np.exp(10*(kl/kcut-1))+1)

SkList = []
print(f'Calculating ({len(kpoints)} blocks):', end=' ', flush=True)
for iBlock, kpoints_i in enumerate(kpoints):
  phase = np.exp((2j*np.pi)*np.dot(kpoints_i, cellMap.T))
  Hk = np.tensordot(phase, Hwannier, axes=1)
  Ek,Vk = np.linalg.eigh(Hk)
  #--- break H degeneracy with a magnetic field normal to plane:
  Sk = np.tensordot(phase, Swannier, axes=1)
  Sk = np.einsum('kba,kibc->kiac', Vk.conjugate(), np.einsum('kibc,kcd->kibd', Sk, Vk))
  Etol = 1e-6 #degneracy threshold
  HBk = np.zeros(Hk.shape, dtype=np.complex128)
  for ik,E in enumerate(Ek):
    HBk[ik] = np.diag(E)
    HBk[ik] += (0.1*Etol) * np.tensordot(kNormal, Sk[ik], axes=1) #Magnetic field Hamiltonian
    if modelSOC != "none":
      kc = np.dot(kpoints_i, G)
      alphak = 0.5 * alpha * fcut(kc[ik]) #0.5 from Sk
      if modelSOC == "rashba":
        Larmor = alphak * np.array([-kc[ik][1], kc[ik][0], 0])
      if modelSOC == "psh":
        Larmor = alphak * np.array([0,kc[ik][2],0])
      HBk[ik] += np.einsum("a,abc->bc", Larmor, Sk[ik])
    HBk[ik] *= np.where(np.abs(E[None,:]-E[:,None])<Etol, 1., 0.) #Keep only within degenerate subspaces
  Ek,Vk2 = np.linalg.eigh(HBk)
  #--- transform spins to eigenbasis
  SkList.append(np.einsum('kbd,kibd->kid', Vk2.conjugate(), np.einsum('kibc,kcd->kibd', Sk, Vk2)).real) #transform to eigenbasis, and keep diagonal
  print(iBlock+1, end=' ', flush=True)
print('done.', flush=True)
Sk = np.array(SkList).reshape(-1, 3, nBands)
Sk.tofile(f"Sk-b{b+1}-k{k0[0]:+.2f}{k0[1]:+.2f}{k0[2]:+.2f}-{modelSOC}.dat")
np.savetxt("Sk-b156.txt", Sk[:,:,b])

#Plot:
S = 0.5 * np.reshape((Sk[..., b] @ rotNet.T).T, (3,) + kCart.shape[1:]) #switch spins to basis of rotated plane
SzMag = np.abs(S[2])
SxyMag = np.sqrt(np.sum(S[:2]**2, axis=0))
SMax = (np.sqrt(np.sum(S[:]**2, axis=0))).max()
print("SMax: ",SMax)

exit()

cm1 = mcol.LinearSegmentedColormap.from_list("MyColorMap",['b', 'deepskyblue', 'limegreen', 'yellow', 'r'])
#cm1 = 'jet'

fig, ax = plt.subplots(1, 1, figsize=(6.5, 5))
#plt.sca(axes[0])
cf = ax.imshow(S[2].T, cmap=cm1, norm=Normalize(vmin=-0.5, vmax=0.5), origin='upper', interpolation='bicubic', extent=[kCart[0].min(), kCart[0].max(), kCart[1].min(), kCart[1].max()]) #z-component
cbar = fig.colorbar(cf, ax=ax, ticks=[-0.5,-0.25,0,0.25,0.5], shrink=0.8, cmap=cm1).set_label(label=r'$S_z$',size=16)
plt.title(r'min(max) |$\vec{S}_z$|/0.5 = ' + f'{2*SzMag.min():.5g}' + '(' + f'{2*SzMag.max():.5g}' + ')', fontsize=16)
plt.xlabel(r'$k_x$ (bohr$^{-1}$)',fontsize=16)
plt.ylabel(r'$k_y$ (bohr$^{-1}$)',fontsize=16)
plt.xticks(fontsize=13)
plt.yticks(fontsize=13)
plt.savefig(f"Sz-b{b+1}-k{k0[0]:+.2f}{k0[1]:+.2f}{k0[2]:+.2f}.png", dpi=150, bbox_inches='tight')

#plt.sca(axes[1])
fig, ax = plt.subplots(1, 1, figsize=(6.5,5))
cv = ax.quiver(kCart[0], kCart[1], S[0], S[1], S[2], cmap=cm1, scale=0.8, norm=Normalize(vmin=-0.5, vmax=0.5), minlength=1.5)
#cv = ax.quiver(kCart[0], kCart[1], S[0], S[1], S[2], cmap=cm1, norm=Normalize(vmin=-0.5, vmax=0.5))
cbar = fig.colorbar(cv, ax=ax, ticks=[-0.5,-0.25,0,0.25,0.5], shrink=0.8)
cbar.ax.tick_params(labelsize=13) # change colorbar tick size
cbar.set_label(label=r'$S_z$',size=16)
plt.xlim(kCart[0].min(), kCart[0].max())
plt.ylim(kCart[1].min(), kCart[1].max())
plt.gca().autoscale(enable=True, axis='both', tight=True)
plt.gca().axis('equal')
plt.title(r'max |$\vec{S}_\parallel$|/0.5 = ' + f'{2*SxyMag.max():.3g}', fontsize=16)
plt.xlabel(r'$k_x$ (bohr$^{-1}$)',fontsize=16)
plt.ylabel(r'$k_y$ (bohr$^{-1}$)',fontsize=16)
plt.xticks(fontsize=13)
plt.yticks(fontsize=13)
plt.savefig(f"SpinTexture-b{b+1}-k{k0[0]:+.2f}{k0[1]:+.2f}{k0[2]:+.2f}.png", dpi=150, bbox_inches='tight')
#plt.show()
